//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HID AP.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HIDAP_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDC_OPEN                        1000
#define IDC_BUTTON_OPEN_DEVICE          1000
#define IDC_BUTTON_CODE_FILE            1001
#define IDC_OPEN_STATUS                 1006
#define IDC_STATUS_RESULT               1007
#define IDC_Close                       1008
#define IDC_BUTTON_CLOSE_DEVICE         1008
#define IDC_EDIT_CODE_FILE              1009
#define IDC_EDIT_CODE_SIZE              1010
#define IDC_EDIT_CODE_CHECKSUM          1011
#define IDC_STATIC_LOAD_FILE            1012
#define IDC_STATIC_FILE_NAME            1013
#define IDC_STATIC_FILE_SIZE            1014
#define IDC_STATIC_CHECKSUM             1015
#define IDC_BUTTON_BURN_APROM           1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
