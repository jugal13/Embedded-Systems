
NOTE: 
	This demo code needs to work with PC tool: AMCAP. AMCAP tool is freeware and could be download by internet.

	This demo code cannot work with windows USB Video device.